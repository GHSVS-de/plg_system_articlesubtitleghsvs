<?php
defined('_JEXEC') or die;

$Autoren = implode(' und ', $this->AutorenNames);
?>
<p class="autorDanke">
Vielen Dank an <?php echo $Autoren?>&nbsp;!&nbsp;!&nbsp;!
</p>
